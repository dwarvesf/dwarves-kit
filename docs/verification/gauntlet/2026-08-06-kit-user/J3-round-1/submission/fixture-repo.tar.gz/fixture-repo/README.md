# shout

Tiny demo CLI.

## Usage

    node cli.js --uppercase hello   # prints HELLO
    node cli.js --upper --repeat 3 hello   # prints HELLO three times
