# Spec: add `--repeat N` flag to the shout CLI
Generated: 2026-08-06
Status: SHIPPED

## Problem
`shout --upper hello` prints the transformed text exactly once. The team wants to print the
result N times in one invocation (`shout --upper --repeat 3 hello`) instead of piping the
command through an external loop.

## Solution

### Approaches considered
1. **Wrap the existing print in a loop, `--repeat` parsed alongside `--upper`.** Minimal diff,
   no new dependency, keeps the single-file CLI shape. Tradeoff: hand-rolled arg parsing has to
   handle `--repeat` appearing before or after `--upper`.
2. **Adopt a CLI arg-parsing library (e.g. `commander`).** Cleaner flag handling, but adds a
   runtime dependency to a two-line demo CLI for one flag; disproportionate.

### Chosen approach + why
Approach 1. The CLI is a tiny fixture (`cli.js`, no dependencies); a parsing library is
disproportionate ceremony for a second flag. Hand-parse `--repeat`'s value wherever it appears
in argv.

### Extensibility & boundaries
- If more flags are added later, this hand-rolled parsing becomes a split candidate for a real
  arg-parser. Not yet: one additional flag does not justify it.
- Unit boundary: one function extracts and validates `--repeat`'s value from argv, independent
  of the `--upper` handling.

### Architecture
See `## Picture` below.

## Picture
```
argv: [--upper] [--repeat N] <text>
         |            |
         v            v
   uppercase(text)  parseRepeat(argv) -> N | error
         |            |
         +-----+------+
               v
     print uppercase(text), N times
```

## Design
obvious: a loop around an existing single-line print, no new component, no schema, no external
integration, no irreversible decision.

## Technical Design

### Interfaces (I/O contract)
- Inputs: `process.argv` — `--upper`, optional `--repeat <N>`, and the text argument, in any
  relative order. The text argument is whichever remaining token is not `--upper`, `--repeat`,
  or `--repeat`'s value; with today's single-text-arg CLI that is the one token left after both
  flags (and `--repeat`'s value) are removed.
- Outputs: the uppercased text printed to stdout, N times (one per line); on invalid `--repeat`,
  an error message on stderr and a non-zero exit code, nothing printed to stdout. `--repeat`
  without `--upper` falls through to the existing usage error (unchanged from today), same as
  `--upper` without `--repeat` falls through to printing once.
- Invariants: omitting `--repeat` is equivalent to `--repeat 1` (today's behavior is unchanged
  by default). A duplicated `--repeat` (e.g. `--repeat 3 --repeat 5`) uses the last occurrence,
  the same last-one-wins convention as most CLI flag parsers.

### Data model changes
None.

### API changes
None (CLI-only change).

### UI changes
None.

### Infrastructure changes
None.

## Task Breakdown

### Phase 1: Implement and test
- [x] **TASK-001: Add `--repeat N` parsing + validation to `cli.js`**
  - Files: `cli.js`
  - `--repeat` accepts only a positive integer (N >= 1). N=0, negative, non-numeric, or
    non-integer input is rejected: print an error to stderr, exit 1, nothing printed to stdout.
  - Acceptance criteria:
    - [x] `--repeat 3` prints the uppercased text 3 times
    - [x] `--repeat 1` (or omitted) prints it once
    - [x] `--repeat 0`, a negative number, or a non-numeric value exits non-zero with a stderr message

- [x] **TASK-002: Test coverage + wire `npm test`**
  - Files: `test/cli.test.js`, `package.json`
  - Add `"scripts": {"test": "node --test"}` to `package.json` (currently has no `test` script
    at all, so `npm test` fails today regardless of TASK-001).
  - Acceptance criteria:
    - [x] Test N=1 and N=3 assert the exact repeated output
    - [x] Test N=0, negative, and non-numeric each assert a non-zero exit code
    - [x] `npm test` runs all of the above and exits 0

## After state
- [x] `node cli.js --upper --repeat 3 hi` prints `HI` three times. (Today: `--repeat` does not exist.)
- [x] `node cli.js --upper --repeat banana hi` exits non-zero with a stderr error. (Today: N/A.)
- [x] `npm test` runs a real test file and exits 0, checkable by `npm test`.

## Acceptance Criteria (global)
- [x] Both task ACs met
- [x] `npm test` exits 0
- [x] No regressions: `node cli.js --upper hello` still prints `HELLO` once

## Verification
`npm test` (runs `node --test`, covering N=1, N=3, N=0, negative, and non-numeric cases) AND
manually: `node cli.js --upper --repeat 3 hi | grep -c HI` must equal 3.

## Edge Cases
1. `--repeat 0` — rejected (a "print zero times" request produces no observable output, which
   this CLI treats as a usage error rather than a silent no-op).
2. `--repeat -1` (negative) — rejected, same reason.
3. `--repeat banana` (non-numeric) — rejected.
4. `--repeat 1.5` (non-integer) — rejected (not a whole number of repeats).
5. `--repeat` given with no value (last arg) — rejected, treated the same as a non-numeric value.
6. `--repeat` appearing before `--upper` in argv (`shout --repeat 3 --upper hi`) — still works;
   parsing does not assume flag order.
7. No `--repeat` at all — behaves exactly as before (prints once).
8. `--repeat` given but `--upper` missing (`shout --repeat 3 hi`) — falls through to the existing
   usage error, unchanged from today's behavior for any invocation without `--upper`.
9. `--repeat` given twice (`--repeat 3 --repeat 5`) — last occurrence wins.

## Out of Scope
- A `--repeat` upper bound / rate limiting. Not asked for; this is a local demo CLI. A very
  large N piped into a consumer that closes its pipe early (e.g. `| head -1`) may surface a
  broken-pipe error from Node instead of a clean exit; accepted for this local demo fixture,
  same as the pre-existing `--repeat`-less CLI's behavior under the same condition.
- Repeating with a delay between prints. Not asked for.

## Decision Log
- **DEC-001**: Reject N=0 rather than silently printing nothing.
  - **Rationale**: a silent no-op on a CLI is a confusing failure mode; an explicit error is
    more debuggable.
  - **Rejected alternative**: treat 0 as a valid "print nothing" case. Rejected — no user need
    for it, and it would be indistinguishable from a bug.
- **DEC-002** (added by `/kit:spec-validate` pass, 2026-08-06): `package.json` has no `test`
  script today; TASK-002 now explicitly wires `"scripts.test": "node --test"` so `npm test`
  (this spec's own `## Verification` command) actually runs something instead of failing with
  "Missing script: test" independent of whether the feature is implemented.
- **DEC-003**: duplicate `--repeat` uses last-one-wins.
  - **Rationale**: matches common CLI flag-parser convention; no user need for an error here.

## Review
Written by `/kit:review-team` (full-lane multi-lens review, before ship), 2026-08-06.

### Security
No findings that change the verdict. One residual, non-blocking note: `--repeat` has no upper
bound, so a very large N drives an unbounded synchronous print loop (local CPU/time cost); this
is a local, single-user, no-network fixture CLI, and the spec's `## Out of Scope` already
accepts this tradeoff explicitly. No injection, auth, secrets, or dependency-risk surface (no
new dependency added). Lens verdict: SHIP.

### Architecture
Implementation matches the spec's chosen approach (hand-rolled `parseRepeat`, no arg-parsing
library) exactly; `rest`/`repeat` split cleanly decouples `--repeat` parsing from `--upper`
handling per the spec's stated unit boundary. Cosmetic-only nit: the missing-value error message
literally interpolates `"undefined"` (e.g. `got "undefined"`) — correct behavior, mildly odd
wording; not worth a fix for a demo CLI. Lens verdict: SHIP.

### Test coverage
Initial pass found two gaps (FIX THEN SHIP): (1) no test for `--repeat` given with no trailing
value (Edge Case 5), and (2) the four rejection tests asserted only exit code + empty stdout,
never the stderr message content. **Both fixed** in `test/cli.test.js`: added a "no trailing
value" test and stderr-content assertions on all four rejection tests (0, negative, non-numeric,
non-integer). `npm test` re-run after the fix: 11/11 pass. Lens verdict after fix: SHIP.

### Findings
- All findings above were either accepted-as-is (security's N-upper-bound note, architecture's
  cosmetic message wording) or fixed (test-coverage's two gaps).

### TODOs
- None open.

### Verdict: SHIP

## Open questions
(none)
