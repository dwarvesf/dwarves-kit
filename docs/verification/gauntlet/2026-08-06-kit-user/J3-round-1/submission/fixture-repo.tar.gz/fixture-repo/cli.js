#!/usr/bin/env node
const argv = process.argv.slice(2);

function parseRepeat(argv) {
  let repeat = 1;
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--repeat") {
      const raw = argv[i + 1];
      const n = Number(raw);
      if (raw === undefined || !Number.isInteger(n) || n < 1) {
        return { error: `error: --repeat requires a positive integer, got "${raw}"` };
      }
      repeat = n; // last occurrence wins
      i++; // skip the value token
      continue;
    }
    rest.push(argv[i]);
  }
  return { repeat, rest };
}

const parsed = parseRepeat(argv);
if (parsed.error) {
  console.error(parsed.error);
  process.exit(1);
}

const { repeat, rest } = parsed;
if (rest[0] === "--upper") {
  const out = (rest[1] || "").toUpperCase();
  for (let i = 0; i < repeat; i++) console.log(out);
} else {
  console.error("usage: cli.js --upper [--repeat N] <text>");
  process.exit(1);
}
