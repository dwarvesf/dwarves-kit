# Proof of done: --repeat N flag
Profile: feature   Proof class: behavioral
Spec: docs/specs/SPEC-001-repeat-flag.md

## 1. Acceptance criteria

| # | Criterion | Status | Evidence |
|---|---|---|---|
| 1 | `--repeat 3` prints the uppercased text 3 times | PASS | R1 below |
| 2 | `--repeat 1` (or omitted) prints it once | PASS | R1 below |
| 3 | `--repeat 0`, negative, non-numeric, non-integer, or missing-value each exit non-zero with a stderr message | PASS | R1 below |
| 4 | `npm test` exits 0 | PASS | R1 below |
| 5 | No regression: `--upper hello` (no `--repeat`) still prints `HELLO` once | PASS | R1 below |

## 2. Implementation

| Aspect | Detail |
|---|---|
| What | `cli.js`: `parseRepeat(argv)` extracts/validates `--repeat`'s value (last-one-wins on duplicates), independent of `--upper` handling; the print becomes a loop over the validated count. |
| Where | `cli.js`, `package.json` (`scripts.test`), `test/cli.test.js` |
| How it runs | `node cli.js --upper [--repeat N] <text>`; `npm test` runs `node --test` |
| Reversibility | Plain `git revert`; no persistent state, no migration, no external side effect |

## 3. Confirmation (runs)

| Run | When (ISO+tz) | Command | Exit | Verdict |
|---|---|---|---|---|
| R1 | 2026-08-06T00:00:00Z | `npm test` | 0 | PASS (11/11) |
| R2 | 2026-08-06T00:00:00Z | `npm test` (cli.js reverted to pre-feature commit `20cd10c`) | 1 | FAIL (2/11) — NEGATIVE CONTROL |
| R3 | 2026-08-06T00:00:00Z | `npm test` (cli.js restored) | 0 | PASS (11/11) — RESTORE |

## 4. Run detail

### R1 GREEN
Command: `npm test`
Exit: 0
```
# tests 11
# pass 11
# fail 0
```
Manual cross-check of the card's own probes:
```
$ node cli.js --upper --repeat 3 hi | grep -c HI
3
$ node cli.js --upper --repeat 1 hi | grep -c HI
1
$ node cli.js --upper --repeat banana hi; echo "exit=$?"
error: --repeat requires a positive integer, got "banana"
exit=1
$ node cli.js --upper hello
HELLO
```

### R2 NEGATIVE CONTROL
`cli.js` temporarily reverted to its pre-feature state (`git show 20cd10c:cli.js`, the commit
before this spec's implementation), same `test/cli.test.js` re-run against it, in the same
working tree (no throwaway worktree available in this sandbox; the file was restored
immediately after this run completed — see R3).
Command: `npm test`
Exit: 1
```
# tests 11
# pass 2
# fail 9
```
9 of 11 tests fail (every `--repeat`-specific assertion) — confirms the test suite actually
exercises the feature rather than passing vacuously.

### R3 ROLLBACK/RESTORE
`cli.js` restored to the feature version (`cp` of the pre-R2 file back into place, verified
against `git diff` showing no residual change).
Command: `npm test`
Exit: 0
```
# tests 11
# pass 11
# fail 0
```

## 5. Reproduce
`npm test` (from `/work/fixture-repo`, any commit at or after `be7a55a`).
