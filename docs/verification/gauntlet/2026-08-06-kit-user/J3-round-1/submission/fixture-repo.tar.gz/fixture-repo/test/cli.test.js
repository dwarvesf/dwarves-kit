const { test } = require("node:test");
const assert = require("node:assert/strict");
const { execFileSync } = require("node:child_process");
const path = require("node:path");

const CLI = path.join(__dirname, "..", "cli.js");

function run(args) {
  try {
    const stdout = execFileSync("node", [CLI, ...args], { encoding: "utf8" });
    return { code: 0, stdout, stderr: "" };
  } catch (err) {
    return { code: err.status, stdout: err.stdout, stderr: err.stderr };
  }
}

test("--upper hi (no --repeat) prints HI once", () => {
  const { code, stdout } = run(["--upper", "hi"]);
  assert.equal(code, 0);
  assert.equal(stdout, "HI\n");
});

test("--repeat 1 prints HI once", () => {
  const { code, stdout } = run(["--upper", "--repeat", "1", "hi"]);
  assert.equal(code, 0);
  assert.equal(stdout, "HI\n");
});

test("--repeat 3 prints HI three times", () => {
  const { code, stdout } = run(["--upper", "--repeat", "3", "hi"]);
  assert.equal(code, 0);
  assert.equal(stdout, "HI\nHI\nHI\n");
});

test("--repeat before --upper still works", () => {
  const { code, stdout } = run(["--repeat", "2", "--upper", "hi"]);
  assert.equal(code, 0);
  assert.equal(stdout, "HI\nHI\n");
});

test("--repeat 0 is rejected", () => {
  const { code, stdout, stderr } = run(["--upper", "--repeat", "0", "hi"]);
  assert.notEqual(code, 0);
  assert.equal(stdout, "");
  assert.match(stderr, /--repeat requires a positive integer, got "0"/);
});

test("--repeat -1 (negative) is rejected", () => {
  const { code, stdout, stderr } = run(["--upper", "--repeat", "-1", "hi"]);
  assert.notEqual(code, 0);
  assert.equal(stdout, "");
  assert.match(stderr, /--repeat requires a positive integer, got "-1"/);
});

test("--repeat banana (non-numeric) is rejected", () => {
  const { code, stdout, stderr } = run(["--upper", "--repeat", "banana", "hi"]);
  assert.notEqual(code, 0);
  assert.equal(stdout, "");
  assert.match(stderr, /--repeat requires a positive integer, got "banana"/);
});

test("--repeat 1.5 (non-integer) is rejected", () => {
  const { code, stdout, stderr } = run(["--upper", "--repeat", "1.5", "hi"]);
  assert.notEqual(code, 0);
  assert.equal(stdout, "");
  assert.match(stderr, /--repeat requires a positive integer, got "1.5"/);
});

test("--repeat with no trailing value is rejected", () => {
  const { code, stdout, stderr } = run(["--upper", "hi", "--repeat"]);
  assert.notEqual(code, 0);
  assert.equal(stdout, "");
  assert.match(stderr, /--repeat requires a positive integer, got "undefined"/);
});

test("duplicate --repeat: last one wins", () => {
  const { code, stdout } = run(["--upper", "--repeat", "3", "--repeat", "2", "hi"]);
  assert.equal(code, 0);
  assert.equal(stdout, "HI\nHI\n");
});

test("--repeat without --upper falls through to usage error", () => {
  const { code } = run(["--repeat", "3", "hi"]);
  assert.notEqual(code, 0);
});
