# shout

Tiny demo CLI.

## Usage

    node cli.js --upper hello   # prints HELLO
