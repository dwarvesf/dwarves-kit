
<!-- kit:adopt -->
## Operating layer (dwarves-kit)

@AGENTS.md

Before touching code, classify the lane: `bash /tmp/probe-home/.claude/dwarves-kit/bin/classify lane classify "<task>"`.
A full-lane change records its gates via `/tmp/probe-home/.claude/dwarves-kit/bin/gate ledger` or the ship-gate blocks the push.
<!-- /kit:adopt -->
