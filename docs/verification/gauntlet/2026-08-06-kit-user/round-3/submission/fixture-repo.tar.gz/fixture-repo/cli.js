#!/usr/bin/env node
const arg = process.argv[2];
if (arg === "--upper") console.log((process.argv[3] || "").toUpperCase());
else { console.error("usage: cli.js --upper <text>"); process.exit(1); }
