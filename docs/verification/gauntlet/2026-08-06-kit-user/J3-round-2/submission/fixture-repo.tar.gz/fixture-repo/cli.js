#!/usr/bin/env node
const args = process.argv.slice(2);

const USAGE = "usage: cli.js --upper [--repeat N] <text>";

let upper = false;
let repeat = 1;
const rest = [];

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  if (arg === "--upper") {
    upper = true;
  } else if (arg === "--repeat") {
    const raw = args[++i];
    if (raw === undefined || !/^-?\d+$/.test(raw)) {
      console.error(`${USAGE} (N must be an integer, got ${JSON.stringify(raw)})`);
      process.exit(1);
    }
    repeat = Number(raw);
    if (repeat <= 0) {
      console.error(`${USAGE} (N must be >= 1, got ${repeat})`);
      process.exit(1);
    }
  } else {
    rest.push(arg);
  }
}

if (!upper) {
  console.error(USAGE);
  process.exit(1);
}

const text = (rest[0] || "").toUpperCase();
for (let i = 0; i < repeat; i++) console.log(text);
