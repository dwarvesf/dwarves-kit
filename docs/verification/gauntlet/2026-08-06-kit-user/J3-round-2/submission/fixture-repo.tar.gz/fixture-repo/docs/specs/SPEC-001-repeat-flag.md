# Spec: add `--repeat N` flag to the shout CLI
Generated: 2026-08-06
Status: VALIDATED
Lane: full

## Problem

`shout --upper hello` prints the uppercased text once. The team wants to repeat
the output N times in one invocation (`shout --upper --repeat 3 hello`) instead
of piping through a shell loop, so scripts and demos can request repetition
directly from the CLI.

## Solution

### Approaches considered
1. **Add a `--repeat N` flag, parsed alongside `--upper` in a small manual arg
   loop.** Flags can appear in any order (`--upper --repeat 3 hello` or
   `--repeat 3 --upper hello`). Simple, no new dependency, fits the CLI's
   existing size (single file, no framework).
2. **Adopt a full argv-parsing library (e.g. `yargs`/`commander`).** Rejected:
   this is a 2-flag toy CLI; a parsing library is disproportionate weight for
   one new flag and adds a runtime dependency the fixture repo doesn't have.
3. **Wrap the existing binary in a shell loop (`for i in ...; do shout ...;
   done`) instead of changing the CLI.** Rejected: pushes the repeat concept
   out of the tool and into every caller; the team explicitly asked for the
   flag on the CLI itself.

### Chosen approach + why
Approach 1: a manual flag loop. It is the smallest change that satisfies the
ask, keeps the CLI dependency-free, and mirrors the existing `--upper` parsing
style already in `cli.js`.

### Extensibility & boundaries
- If more flags are added later (e.g. `--sep`, `--prefix`), the same manual
  loop scales to a few more `if`/`else if` branches before a real parser
  becomes worth its weight; that threshold is not crossed by this change.
- Unit boundary: argument parsing and output stay in one function in `cli.js`,
  matching the current single-file scope of the tool.

### Architecture
See `## Design` below.

## Picture
```
argv: [--upper] [--repeat N] <text>
        |            |          |
        v            v          v
  +------------------------------------+
  |          cli.js (arg loop)         |
  |  upper=bool  repeat=int>=1  text   |
  +------------------------------------+
                  |
                  v
         print(text.toUpperCase()) x repeat
```

## Design

obvious: a single new flag parsed in the existing manual arg loop, no new
component, no data model, no external integration -- collapsed per the spec
template's rule for non-design-bearing work.

## Technical Design

### Interfaces (I/O contract)
- Inputs / consumes: `process.argv` -- `--upper` (bool flag), `--repeat N`
  (optional, integer, default `1`), and the text positional.
- Outputs / produces: `console.log(text)` printed exactly `N` times to stdout;
  a non-zero exit with a `usage:` message on stderr for invalid input.
- Invariants: with no `--repeat`, behavior is byte-identical to today
  (prints once) -- this is the backward-compatibility invariant a future
  change to this file must not break.

### Data model changes
None.

### API changes
None (CLI-only).

### UI changes
None.

### Infrastructure changes
None.

## Task Breakdown

### Phase 1: Implement and test
- [ ] **TASK-001: Add `--repeat N` parsing to `cli.js`**
  - Files: `cli.js`
  - Accept `--repeat` in any position relative to `--upper`.
  - Acceptance criteria:
    - [ ] `--repeat 3 --upper hi` and `--upper --repeat 3 hi` both print `HI` three times
    - [ ] No `--repeat` given: prints once (unchanged behavior)
- [ ] **TASK-002: Validate N and error on bad input**
  - Files: `cli.js`
  - Acceptance criteria:
    - [ ] `N` non-numeric (e.g. `banana`): usage error on stderr, exit code 1
    - [ ] `N` = 0: usage error on stderr, exit code 1
    - [ ] `N` negative (e.g. `-2`): usage error on stderr, exit code 1
- [ ] **TASK-003: Tests**
  - Files: `test/cli.test.js`
  - Acceptance criteria:
    - [ ] Covers N=1, N=3, N=0, negative, non-numeric, and the no-flag default
    - [ ] `npm test` exits 0

## After state
- [ ] `shout --upper --repeat 3 hello` prints `HELLO` three times. (Today: `--repeat` does not exist.)
- [ ] `shout --upper --repeat 1 hello` prints `HELLO` once, checkable by `node cli.js --upper --repeat 1 hello`.
- [ ] `shout --upper --repeat 0 hello` / negative / non-numeric all exit non-zero with a usage message, checkable by `node cli.js --upper --repeat 0 hello; echo $?`.
- [ ] `shout --upper hello` (no `--repeat`) is unchanged, checkable by `node cli.js --upper hello`.

## Acceptance Criteria (global)
- [ ] All tasks pass their individual acceptance criteria
- [ ] Tests cover happy path (N=1, N=3) + edge cases (N=0, negative, non-numeric)
- [ ] No regressions in existing `--upper`-only behavior

## Verification
`cd /work/fixture-repo && npm test` (runs `test/cli.test.js` via `node --test`, which exercises N=1, N=3, N=0, negative, non-numeric, and the no-`--repeat` default).

Manual spot check: `node cli.js --upper --repeat 3 hi` prints `HI` three times; `node cli.js --upper --repeat banana hi` exits non-zero.

## Test plan

Coverage matrix (one case per row, `test/cli.test.js`, run via `npm test`):

| # | Input | Expected |
|---|---|---|
| 1 | `--upper hi` (no `--repeat`) | prints `HI` once, exit 0 (backward-compat) |
| 2 | `--upper --repeat 1 hi` | prints `HI` once, exit 0 |
| 3 | `--upper --repeat 3 hi` | prints `HI` three times, exit 0 |
| 4 | `--repeat 3 --upper hi` (order swapped) | prints `HI` three times, exit 0 |
| 5 | `--upper --repeat 0 hi` | usage error on stderr, exit 1 |
| 6 | `--upper --repeat -2 hi` | usage error on stderr, exit 1 |
| 7 | `--upper --repeat banana hi` | usage error on stderr, exit 1 |
| 8 | no `--upper` at all | usage error on stderr, exit 1 (unchanged) |

## Edge Cases
1. `--repeat` given with no value following it (end of argv): usage error, exit 1.
2. `--repeat 3` given without `--upper`: still an error (existing `--upper`-required behavior is unchanged; `--repeat` does not imply `--upper`).
3. `--repeat` passed more than once: last one wins (simplest manual-loop behavior; no stated need for accumulation).

## Failure modes
Not applicable -- no external provider, data loss, or migration surface.

## Out of Scope
- A general-purpose argv parser / dependency (see Solution, approach 2 rejected).
- Non-integer repeat counts (e.g. fractional or a range).

## Decision Log
- **DEC-001**: Errors on N=0, negative, and non-numeric input (reject, exit 1) rather than silently clamping to 1 or treating 0 as "print nothing".
  - **Rationale**: a silent clamp hides a likely typo (e.g. `--repeat 0` was probably meant to be `--repeat 10`); failing loudly is safer for a CLI with no other feedback loop.
  - **Rejected alternative**: treat `--repeat 0` as "print nothing" (valid degenerate case). Rejected because it is surprising and gives no signal that anything was wrong.

## Validation (`/kit:spec-validate` self-run)

- **Reviewer 1 (Security):** no external input beyond argv/stdin; no secrets, no network, no filesystem writes. Passed.
- **Reviewer 2 (Failure Mode):** `--repeat` with no following value, non-numeric, 0, and negative are all covered above (Edge Cases + Decision Log). Passed.
- **Reviewer 3 (Assumption Destroyer):** assumed "N must be a positive integer" -- checked against the task ask ("prints the result three times") which only implies N>=1; nothing in the ask implies 0 or negative should be meaningful. Holds.
- **Reviewer 4 (Scope Critic):** full lane requires a non-empty `## Picture`; present above. Task Breakdown matches the Picture (arg loop -> validate -> repeat-print).
- **Reviewer 5 (Solution-Design & Extensibility):** approaches considered above (3), rejected alternatives justified, extensibility boundary named. Passed.
- **Reviewer 6 (Design Record Auditor, BLOCKING):** this spec is NOT design-bearing (no new component/module, no schema, no external integration, one obvious approach) -- `## Design` correctly collapsed to the one-line `obvious:` form per the template rule, so the blocking check does not apply. Passed.

### Verdict: APPROVED

Status flipped to `VALIDATED` above; no implementation commits exist yet at this point in history (this validation is committed on its own before any code change).

## Review

### Verdict: SHIP

### Findings
No findings at any severity. Notes (informational, not blocking):
- `cli.js` uses a manual `arg`/`++i` loop rather than a parsing library, matching
  the Solution section's chosen approach and the file's pre-existing style.
- The no-`--repeat` path is byte-identical in behavior to the pre-change CLI
  (verified by test 1 and the `git stash` negative control in
  `docs/verification/repeat-flag.md`).
- Error messages go to stderr with a non-zero exit for all three invalid-N
  cases (0, negative, non-numeric), matching Decision Log DEC-001.

### TODOs (open follow-ups)
None.

## Open questions
(none)
