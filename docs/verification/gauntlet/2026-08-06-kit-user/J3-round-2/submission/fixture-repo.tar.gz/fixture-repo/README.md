# shout

Tiny demo CLI.

## Usage

    node cli.js --upper hello                  # prints HELLO
    node cli.js --upper --repeat 3 hello        # prints HELLO three times
    node cli.js --repeat 3 --upper hello        # flag order doesn't matter

`--repeat N` must be a positive integer; 0, negative, or non-numeric N is a
usage error (exit 1).
