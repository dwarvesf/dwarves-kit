# Verification: SPEC-001 `--repeat N` flag

## 2026-08-06 PASS -- repeat-flag [green]

- Command: `node cli.js --upper --repeat 3 hi`
- Exit: 0
- Output:
  ```
  HI
  HI
  HI
  ```
- Command: `node cli.js --upper --repeat 1 hi`
- Exit: 0
- Output: `HI`
- Command: `node cli.js --upper --repeat banana hi`
- Exit: 1
- Output (stderr): `usage: cli.js --upper [--repeat N] <text> (N must be an integer, got "banana")`
- Command: `npm test` -- 8/8 `node --test` cases green (N=1, N=3, flag-order swap, N=0, N=-2, N=banana, no-`--repeat`, no-`--upper`)
- Verdict: PASS

## 2026-08-06 NEGATIVE CONTROL -- repeat-flag [reverted]

Reverted `cli.js` to the pre-feature commit (`git show main:cli.js`, the
single-line `--upper`-only version with no `--repeat` support) and re-ran the
exact same green-run command against it:

- Command: `node cli.js --upper --repeat 3 hi` (against the PRE-feature `cli.js`)
- Exit: 0
- Output: `--REPEAT` (the old code takes `process.argv[3]` -- here `"--repeat"`
  itself -- as the text to uppercase; it has no concept of a `--repeat` flag)

This is the expected RED: the old code does not print `HI` three times (or at
all); it silently misparses the new flag as the text argument. Restored the
post-feature `cli.js` immediately after (`git status` clean, `cli.js` back to
the committed feature version; `npm test` re-confirmed 8/8 green after
restore).

NEGATIVE CONTROL: confirms the green run above is not trivially green -- the
behavior really does come from this change, not a no-op.

Verdict: PASS
