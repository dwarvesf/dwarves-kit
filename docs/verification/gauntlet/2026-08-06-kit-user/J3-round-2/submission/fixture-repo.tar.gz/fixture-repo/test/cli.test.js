const { test } = require("node:test");
const assert = require("node:assert/strict");
const { spawnSync } = require("node:child_process");
const path = require("node:path");

const CLI = path.join(__dirname, "..", "cli.js");

function run(...args) {
  return spawnSync(process.execPath, [CLI, ...args], { encoding: "utf8" });
}

test("--upper hi (no --repeat) prints HI once", () => {
  const r = run("--upper", "hi");
  assert.equal(r.status, 0);
  assert.equal(r.stdout, "HI\n");
});

test("--upper --repeat 1 hi prints HI once", () => {
  const r = run("--upper", "--repeat", "1", "hi");
  assert.equal(r.status, 0);
  assert.equal(r.stdout, "HI\n");
});

test("--upper --repeat 3 hi prints HI three times", () => {
  const r = run("--upper", "--repeat", "3", "hi");
  assert.equal(r.status, 0);
  assert.equal(r.stdout, "HI\nHI\nHI\n");
});

test("--repeat 3 --upper hi (flag order swapped) prints HI three times", () => {
  const r = run("--repeat", "3", "--upper", "hi");
  assert.equal(r.status, 0);
  assert.equal(r.stdout, "HI\nHI\nHI\n");
});

test("--upper --repeat 0 hi errors, exit 1", () => {
  const r = run("--upper", "--repeat", "0", "hi");
  assert.equal(r.status, 1);
  assert.equal(r.stdout, "");
  assert.match(r.stderr, /usage:/);
});

test("--upper --repeat -2 hi errors, exit 1", () => {
  const r = run("--upper", "--repeat", "-2", "hi");
  assert.equal(r.status, 1);
  assert.equal(r.stdout, "");
  assert.match(r.stderr, /usage:/);
});

test("--upper --repeat banana hi errors, exit 1", () => {
  const r = run("--upper", "--repeat", "banana", "hi");
  assert.equal(r.status, 1);
  assert.equal(r.stdout, "");
  assert.match(r.stderr, /usage:/);
});

test("no --upper at all still errors, exit 1 (unchanged)", () => {
  const r = run("hi");
  assert.equal(r.status, 1);
  assert.equal(r.stdout, "");
  assert.match(r.stderr, /usage:/);
});
